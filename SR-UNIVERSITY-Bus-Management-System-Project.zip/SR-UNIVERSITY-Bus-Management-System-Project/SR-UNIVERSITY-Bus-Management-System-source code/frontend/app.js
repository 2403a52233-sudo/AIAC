function login(){const role=document.getElementById("role").value;window.location.href=role+".html";}
function logout(){window.location.href="index.html";}
function loadData(k){return JSON.parse(localStorage.getItem(k))||[];}
function saveData(k,v){localStorage.setItem(k,JSON.stringify(v));}