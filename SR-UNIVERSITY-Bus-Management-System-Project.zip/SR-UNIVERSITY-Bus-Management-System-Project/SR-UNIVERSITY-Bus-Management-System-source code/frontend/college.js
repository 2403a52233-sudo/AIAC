const API = "http://localhost:3000";

async function loadAnalytics() {
    try {
        const buses = await fetch(API + "/buses").then(r => r.json());
        const routes = await fetch(API + "/routes").then(r => r.json());
        const drivers = await fetch(API + "/drivers").then(r => r.json());

        document.getElementById("totalBuses").innerText = buses.length;
        document.getElementById("totalRoutes").innerText = routes.length;
        document.getElementById("totalDrivers").innerText = drivers.length;

    } catch (e) {
        console.error("Analytics error:", e);
    }
}

loadAnalytics();
