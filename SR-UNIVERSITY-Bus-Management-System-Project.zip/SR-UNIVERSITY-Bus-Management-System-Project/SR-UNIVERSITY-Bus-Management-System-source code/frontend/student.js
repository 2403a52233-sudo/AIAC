const API = "http://localhost:3000";

/* Load bus list for student dropdown */
async function loadBusList() {
    const buses = await fetch(API + "/buses").then(r => r.json());

    document.getElementById("studentBus").innerHTML =
        buses.map(b => `<option value="${b.number}">${b.number}</option>`).join("");
}

/* Load routes + selected bus details */
async function loadStudentData() {
    const bus = document.getElementById("studentBus").value;

    const routes = await fetch(API + "/routes").then(r => r.json());
    const statusData = await fetch(API + "/status").then(r => r.json());
    const locationData = await fetch(API + "/location").then(r => r.json());

    // Show routes
    document.getElementById("studentRoutes").innerHTML =
        routes.map(r => `<p>${r.name}</p>`).join("");

    // Get status + location for selected bus
    const status = statusData[bus]?.status || "No update";
    const location = locationData[bus]?.location || "No update";

    // Show notifications
    document.getElementById("notifications").innerHTML = `
        <p><b>Bus Status:</b> ${status}</p>
        <p><b>Driver Location:</b> ${location}</p>
    `;
}

/* Ensure buses load BEFORE student data is loaded */
async function initStudent() {
    await loadBusList();  
    loadStudentData();    
}

initStudent();   // start loading
