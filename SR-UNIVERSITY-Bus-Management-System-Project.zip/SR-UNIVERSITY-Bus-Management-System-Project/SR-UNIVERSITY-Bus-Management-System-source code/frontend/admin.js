const API = "http://localhost:3000";

/* Load lists when admin page opens */
loadAll();

async function loadAll() {
    loadBuses();
    loadRoutes();
    loadDrivers();
}

/* UTILITY FUNCTION: show list with edit/delete buttons */
function showList(id, items, type) {
    document.getElementById(id).innerHTML = items.map((item, i) => `
        <p>
            ${Object.values(item)[0]}
            <button onclick="editItem('${type}', ${i})">Edit</button>
            <button onclick="deleteItem('${type}', ${i})" style="background:red;color:white;">Delete</button>
        </p>
    `).join("");
}

/* ================= BUS ================= */

async function addBus() {
    const number = document.getElementById("busNumber").value.trim();
    if (!number) return alert("Enter a bus number");

    await fetch(API + "/buses", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ number })
    });

    document.getElementById("busNumber").value = "";
    loadBuses();
}

async function loadBuses() {
    const res = await fetch(API + "/buses");
    const data = await res.json();
    showList("busList", data, "buses");
}

/* ================= ROUTES ================= */

async function addRoute() {
    const name = document.getElementById("routeName").value.trim();
    if (!name) return alert("Enter a route name");

    await fetch(API + "/routes", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ name })
    });

    document.getElementById("routeName").value = "";
    loadRoutes();
}

async function loadRoutes() {
    const res = await fetch(API + "/routes");
    const data = await res.json();
    showList("routeList", data, "routes");
}

/* ================= DRIVERS ================= */

async function addDriver() {
    const name = document.getElementById("driverName").value.trim();
    if (!name) return alert("Enter a driver name");

    await fetch(API + "/drivers", {
        method: "POST",
        headers: {"Content-Type": "application/json"},
        body: JSON.stringify({ name })
    });

    document.getElementById("driverName").value = "";
    loadDrivers();
}

async function loadDrivers() {
    const res = await fetch(API + "/drivers");
    const data = await res.json();
    showList("driverList", data, "drivers");
}

/* ================= EDIT ITEM ================= */

async function editItem(type, index) {
    let newValue = prompt("Enter new value:");
    if (!newValue) return;

    const body =
        type === "buses"
            ? { number: newValue }
            : { name: newValue };

    await fetch(`${API}/${type}/${index}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
    });

    loadAll();
}

/* ================= DELETE ITEM ================= */

async function deleteItem(type, index) {
    if (!confirm("Are you sure you want to delete this?")) return;

    await fetch(`${API}/${type}/${index}`, {
        method: "DELETE"
    });

    loadAll();
}

/* ================= RESET SYSTEM ================= */

async function resetAll() {
    if (!confirm("This will REMOVE ALL DATA. Continue?")) return;

    await fetch(API + "/reset", {
        method: "POST"
    });

    loadAll();
}
