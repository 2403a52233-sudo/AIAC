const API = "http://localhost:3000";

/* Load bus list for driver dropdown */
async function loadDriverBuses() {
    const res = await fetch(API + "/buses");
    const buses = await res.json();

    document.getElementById("driverBus").innerHTML =
        buses.map(b => `<option value="${b.number}">${b.number}</option>`).join("");
}

loadDriverBuses();

/* Update status for selected bus */
async function updateStatus() {
    const bus = document.getElementById("driverBus").value;
    const status = document.getElementById("routeStatus").value;

    await fetch(API + "/status", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bus, status })
    });

    alert("Status updated for " + bus);
}

/* Update location for selected bus */
async function updateLocation() {
    const bus = document.getElementById("driverBus").value;
    const location = document.getElementById("location").value;

    await fetch(API + "/location", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ bus, location })
    });

    alert("Location updated for " + bus);

    document.getElementById("location").value = "";
}
