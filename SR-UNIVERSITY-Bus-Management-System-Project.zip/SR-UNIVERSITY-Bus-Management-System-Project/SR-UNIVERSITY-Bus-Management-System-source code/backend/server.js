const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

const app = express();
app.use(cors());
app.use(bodyParser.json());

const DATA_FILE = path.join(__dirname, "data.json");

function readData() {
  try {
    return JSON.parse(fs.readFileSync(DATA_FILE));
  } catch (e) {
    return {
      buses: [],
      routes: [],
      drivers: [],
      students: [],
      status: {},     // CHANGED → now stores status per bus
      location: {},   // CHANGED → now stores location per bus
      attendance: []
    };
  }
}

function writeData(data) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

/* ------------------------ BUS ------------------------ */
app.get("/buses", (req, res) => {
  const d = readData();
  res.json(d.buses);
});

app.post("/buses", (req, res) => {
  const d = readData();
  d.buses.push(req.body);
  writeData(d);
  res.json({ ok: true });
});

/* ------------------------ ROUTES ------------------------ */
app.get("/routes", (req, res) => {
  const d = readData();
  res.json(d.routes);
});

app.post("/routes", (req, res) => {
  const d = readData();
  d.routes.push(req.body);
  writeData(d);
  res.json({ ok: true });
});

/* ------------------------ DRIVERS ------------------------ */
app.get("/drivers", (req, res) => {
  const d = readData();
  res.json(d.drivers);
});

app.post("/drivers", (req, res) => {
  const d = readData();
  d.drivers.push(req.body);
  writeData(d);
  res.json({ ok: true });
});

/* ------------------------ STUDENTS ------------------------ */
app.get("/students", (req, res) => {
  const d = readData();
  res.json(d.students);
});

app.post("/students", (req, res) => {
  const d = readData();
  d.students.push(req.body);
  writeData(d);
  res.json({ ok: true });
});

/* ============================================================= */
/* 🔥 DRIVER STATUS — NOW PER BUS                               */
/* ============================================================= */
app.post("/status", (req, res) => {
  const { bus, status } = req.body;
  const d = readData();

  if (!d.status) d.status = {};

  d.status[bus] = {
    status,
    updatedAt: new Date().toISOString()
  };

  writeData(d);
  res.json({ ok: true });
});

// Get all bus statuses
app.get("/status", (req, res) => {
  const d = readData();
  res.json(d.status || {});
});

/* ============================================================= */
/* 🔥 DRIVER LOCATION — NOW PER BUS                             */
/* ============================================================= */
app.post("/location", (req, res) => {
  const { bus, location } = req.body;
  const d = readData();

  if (!d.location) d.location = {};

  d.location[bus] = {
    location,
    updatedAt: new Date().toISOString()
  };

  writeData(d);
  res.json({ ok: true });
});

// Get all bus locations
app.get("/location", (req, res) => {
  const d = readData();
  res.json(d.location || {});
});

/* ------------------------ ATTENDANCE ------------------------ */
app.post("/attendance", (req, res) => {
  const d = readData();
  d.attendance.push({ time: new Date().toISOString() });
  writeData(d);
  res.json({ ok: true });
});

/* ------------------------ HEALTH CHECK ------------------------ */
app.get("/health", (req, res) => {
  res.json({ status: "ok", time: new Date().toISOString() });
});

/* ============================================================= */
/* 🔥 DELETE ITEM (bus/route/driver/student)                    */
/* ============================================================= */
app.delete("/:type/:index", (req, res) => {
  const { type, index } = req.params;
  const d = readData();

  if (!d[type]) return res.status(400).json({ error: "Invalid type" });

  d[type].splice(index, 1);
  writeData(d);

  res.json({ ok: true });
});

/* ============================================================= */
/* 🔥 EDIT ITEM                                                  */
/* ============================================================= */
app.put("/:type/:index", (req, res) => {
  const { type, index } = req.params;
  const d = readData();

  if (!d[type]) return res.status(400).json({ error: "Invalid type" });

  d[type][index] = req.body;
  writeData(d);

  res.json({ ok: true });
});

/* ============================================================= */
/* 🔥 RESET EVERYTHING (Full restart)                            */
/* ============================================================= */
app.post("/reset", (req, res) => {
  const emptyData = {
    buses: [],
    routes: [],
    drivers: [],
    students: [],
    status: {},
    location: {},
    attendance: []
  };

  writeData(emptyData);
  res.json({ ok: true, message: "System Reset: All Data Cleared" });
});

/* ------------------------ START SERVER ------------------------ */
const PORT = 3000;
app.listen(PORT, () => console.log("Backend running on port", PORT));
